export class Employee {
    EmployeeID: number;
    FullName: string;
    EmpCode: string;
    Mobile: number;
    Position: string;
}
